# DevMesh

**Privacy-first, on-device AI code review agent.**

`git commit` (or a GitHub PR) triggers diff extraction → a quantized LLM
running on a Snapdragon NPU analyzes the diff → findings stream live to a
mobile triage app → a local HTML/PDF report is generated. No internet
dependency. No code ever leaves the machine.

Built for the Snapdragon® Multiverse Hackathon (Bangalore) — Top 50 team.

## Team

- **Hardik** (Team Lead) — LLM integration, prompt engineering, response parsing, WebSocket server, repo management
- **Vatsal** — React Native mobile app, WebSocket client, HTML/PDF report template
- **Dhruv** — Git hook script, GitHub webhook listener, FastAPI server

## What this is (current state)

A working local pipeline that:
1. Reads a git diff (last commit or staged changes), expanded with full
   function context (`git diff --function-context`)
2. Splits it into per-hunk pieces, one LLM call per hunk
3. Sends each hunk to a local LLM for review (Ollama by default; a
   Qualcomm AI Hub / QNN NPU backend is stubbed in for the production path
   — see `backend/llm_client.py`)
4. Parses the model's output into structured findings (CRITICAL / WARNING / SUGGESTION)
5. Fans out findings to:
   - a live WebSocket stream → the mobile triage app
   - a report (currently a plain-text stub; real Jinja2/WeasyPrint HTML+PDF report in progress)

## Setup — from scratch

### 1. Install Ollama

Go to [ollama.com](https://ollama.com) and download the installer for your OS
(Windows/Mac/Linux). Install it like any normal app. Confirm it worked:

```bash
ollama --version
```

You should see a version number, not an error.

### 2. Pull a model

```bash
ollama pull phi3
```

(A few GB — do this on decent wifi. You only need to do this once.)

> The team's finalized production model is **Qwen3-4B-Instruct-2507** (confirmed
> via direct Qualcomm AI Hub benchmarking on real Snapdragon X Elite CRD
> hardware — native NPU/QAIRT runtime, 4096-token context, 1,301 tok/s
> prefill, 23.1 tok/s decode). Phi-4-Mini-Instruct was evaluated and demoted
> to a documented fallback: on the same hardware it only reaches the
> community llama.cpp runtime (not native NPU), and its NPU-mode context
> caps at 512 tokens. Ollama remains the CPU-only dev/testing and
> live-demo-fallback path throughout — see `backend/llm_client.py` for the
> `DEVMESH_BACKEND` env var that switches between them.

### 3. Start the Ollama server

Usually Ollama auto-starts a background server after install. Check with:

```bash
ollama list
```

If that errors with a connection failure, start it manually in its own
terminal window (leave it running):

```bash
ollama serve
```

### 4. Get the project onto your machine

Clone or download this repo so you have a `devmesh/` folder, e.g.:

```
C:\Users\you\projects\devmesh\        (Windows)
~/projects/devmesh/                    (Mac/Linux)
```

### 5. Install Python dependencies

```bash
cd devmesh/backend
pip install -r requirements.txt
```

(Use `pip3` if you have both Python 2 and 3 installed.)

## Run and usage instructions

### Quick sanity checks (no LLM needed)

These confirm the non-LLM parts work before involving Ollama at all:

```bash
python response_parser.py
```
Expected: prints 3 `Finding(...)` objects.

```bash
python prompt_builder.py
```
Expected: prints the full prompt template filled in with a fake SQL
injection line, followed by the measured prompt-template token overhead.

If either errors out, something's wrong with the Python setup itself
(wrong Python version, missing file) — fix that before moving on.

### Test the LLM connection directly

```bash
python llm_client.py
```

Expected: after a short pause, prints a latency number and the model's raw
text output, roughly:
```
[CRITICAL] auth.py:LINE — SQL injection... Fix: ...
```

**Connection error here?** Ollama isn't running — run `ollama serve` in
another terminal, then retry.

**Messy/non-conforming output?** That's useful information, not a failure
— the parser is deliberately tolerant of format drift (see
`response_parser.py`'s docstring), but if it's consistently unparseable,
the prompt wording in `prompt_builder.py` may need iteration.

### Run the full pipeline against a real git commit

```bash
# from inside the devmesh folder
git init
git add samples/buggy_auth.py
git commit -m "add buggy auth sample"

cd backend
python run_review.py
```

Expected output, roughly:
```
[run_review] Extracting diff from: .
[run_review] Found 1 hunk(s) to review

[run_review] Reviewing hunk 1/1: auth.py (line X)
    -> N finding(s), X.XXs

[run_review] Total LLM latency: X.XXs across 1 call(s)
[run_review] Average per hunk: X.XXs

[ws_broadcaster] WebSocket server listening on ws://0.0.0.0:8765
...

[run_review] Report written to: /full/path/to/devmesh_report.txt
```

Open `devmesh_report.txt` (created in the `backend` folder) to see the
findings.

Try the other sample bugs the same way:

```bash
git add samples/buggy_api.js && git commit -m "add buggy api sample" && python run_review.py
git add samples/buggy_models.py && git commit -m "add buggy models sample" && python run_review.py
```

### Run the mobile app

```bash
cd mobile
npm install
npx expo start
```

Set `SERVER_IP` in `mobile/App.js` to the laptop's LAN IP (phone and laptop
must be on the same WiFi) before connecting — see the comment block at the
top of `App.js` for the exact WebSocket message schema the app expects.

### Benchmark harness

To log per-hunk latency (and, once chunking lands, single-call vs. chunked
latency separately — see Section 7/9/20 of the project knowledge file):

```bash
cd backend
python benchmark.py                 # benchmarks the last commit
python benchmark.py --runs 3        # repeats each hunk 3x and averages
python benchmark.py --staged        # benchmarks staged changes instead
```

Writes timestamped CSV + JSON results to `backend/benchmark_results/`.

### Environment variables (all optional)

| Variable | Purpose | Default |
|---|---|---|
| `DEVMESH_MODEL` | Ollama model name | `qwen3:4b-instruct` |
| `DEVMESH_BACKEND` | `ollama` or `qnn` | `ollama` |
| `DEVMESH_MOCK_LLM` | `1` to bypass the LLM entirely with a canned response | `0` |
| `DEVMESH_TIMEOUT` | LLM call timeout, seconds | `420` |
| `DEVMESH_QNN_BINARY` | Path to the compiled QNN context binary (venue-only) | unset |
| `DEVMESH_QNN_MODEL` | QNN model identifier | `qwen3-4b-instruct-2507` |

### Common issues

| Symptom | Likely cause |
|---|---|
| `Could not reach Ollama at http://localhost:11434` | `ollama serve` isn't running — start it in another terminal |
| `git diff failed` | You're not inside a git repo, or haven't made a commit yet |
| Model output has no `[SEVERITY]` lines at all | Model ignored the format — save the raw output, we'll adjust the prompt |
| Very slow (30s+ per hunk) | Normal for CPU-only inference; log the number via `benchmark.py` — this is exactly why the NPU matters for the pitch |

## License

MIT (see [LICENSE](LICENSE))
