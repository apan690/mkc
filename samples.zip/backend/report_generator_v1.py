"""
report_generator.py

STUB VERSION — Section 12 skeleton milestone, contract UPDATED for the
false-positive reiteration flow (Section 20 work).

Placeholder for the real fpdf2-based PDF report (Vatsal's piece). For now
this writes a plain text report to disk so the pipeline's final step exists
end-to-end and is testable before the real PDF renderer is wired in.

CONTRACT (this is what Vatsal's fpdf2 version needs to match):
  generate_report(decisions: List[FindingDecision], output_path=...) -> str

  Each FindingDecision (see review_session.py) is either:
    - decision == "approved"       -> render the finding as-is
    - decision == "false_positive" -> render the finding, the developer's
                                       comment, and the LLM's reiteration
                                       (verdict + text)

Keep this signature identical when swapping in the real renderer, same
pattern already used for llm_client.py (Ollama -> QNN) and ws_broadcaster.py
(print stub -> real WebSocket) — nothing else in the pipeline should need
to change.
"""

import os
from collections import defaultdict
from datetime import datetime
from typing import List, Optional

from review_session import FindingDecision
from diff_extractor import CommitInfo

SEVERITY_ICONS = {
    "CRITICAL": "\U0001F534",
    "WARNING": "\U0001F7E1",
    "SUGGESTION": "\U0001F7E2",
}

VERDICT_LABELS = {
    "MAINTAINED": "AI maintains this finding",
    "WITHDRAWN": "AI agrees this is a false positive",
    "PARTIALLY_VALID": "AI partially agrees",
}


def generate_report(
    decisions: List[FindingDecision],
    commit_info: Optional[CommitInfo] = None,
    output_path: str = "devmesh_report.txt",
) -> str:
    """
    STUB: writes a plain text report grouped by file, split into approved
    findings and developer-flagged false positives (with the LLM's
    reiteration attached to each false positive), headed by the commit this
    report covers (Section 20 — commit tracking).

    decisions: full list of FindingDecision from review_session.session —
    every finding that was part of the review run, each carrying its final
    mobile-side decision (and, for false positives, the LLM reiteration).
    commit_info: the commit this report covers — review_session.session.get_commit_info().
    """
    by_file = defaultdict(list)
    for d in decisions:
        by_file[d.reviewed_finding.finding.file].append(d)

    lines = []
    lines.append(f"DevMesh Review Report — {datetime.now().strftime('%B %d, %Y %H:%M')}")
    if commit_info:
        lines.append(f"Commit: {commit_info.short_id} — \"{commit_info.message}\"")
        lines.append(f"Author: {commit_info.author_name} <{commit_info.author_email}>")
        lines.append(f"Committed: {commit_info.timestamp}")
    lines.append("")

    if not decisions:
        lines.append("No issues found. Clean diff!")
    else:
        approved_count = sum(1 for d in decisions if d.decision == "approved")
        fp_count = sum(1 for d in decisions if d.decision == "false_positive")
        lines.append(f"{approved_count} approved finding(s), {fp_count} developer-flagged false positive(s)")
        lines.append("")

        for file_path, file_decisions in by_file.items():
            lines.append(f"--- {file_path} ---")
            for d in file_decisions:
                f = d.reviewed_finding.finding
                icon = SEVERITY_ICONS.get(f.severity, "-")
                lines.append(f"  {icon} [{f.severity}] line {f.line}: {f.description}")
                if f.fix:
                    lines.append(f"      Fix: {f.fix}")

                if d.decision == "false_positive":
                    lines.append(f"      Developer comment (flagged as false positive): {d.dev_comment}")
                    verdict_label = VERDICT_LABELS.get(d.llm_verdict, d.llm_verdict or "no reiteration recorded")
                    lines.append(f"      LLM reiteration [{verdict_label}]: {d.llm_reiteration}")
            lines.append("")

    report_text = "\n".join(lines)

    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(report_text)

    return os.path.abspath(output_path)
