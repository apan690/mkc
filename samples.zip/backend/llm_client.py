"""
llm_client.py

Thin wrapper around the local LLM backend.

Section 19.3 decision: review_hunk()'s signature stays identical regardless
of backend — only the internals swap. Backend is selected via DEVMESH_BACKEND:
  - "ollama" (default): CPU-only dev/testing + live-demo fallback (unchanged
    from the pre-orientation skeleton). Always available, always works.
  - "qnn": Qualcomm AI Hub-compiled QNN context binary via the GenieX/QAIRT
    runtime, running on the Snapdragon X Elite NPU. This is the production
    path decided in Section 19.3, but the actual runtime call (_run_qnn
    below) can only be wired up and tested on the physical venue hardware —
    see the NotImplementedError and inline TODOs.

Section 19.4 UPDATE (model finalized, confirmed via AI Hub benchmark data
on real Snapdragon X Elite CRD hardware — see project knowledge Section 19.4):
  PRIMARY:  Qwen3-4B-Instruct-2507 — runs on GenieX/QAIRT (native NPU
            runtime), 4096-token context, 1,301 tok/s prefill, 23.1 tok/s
            decode. Non-thinking variant, no <think> block overhead.
  BACKUP:   Phi-4-Mini-Instruct — on this hardware only reaches GenieX/
            llama.cpp (community runtime, not native QNN), and NPU-mode
            context length is capped at 512 tokens (4096 is only reachable
            via CPU/GPU backend, not NPU, per direct AI Hub checks — see
            Section 19.4 update). Kept as a documented fallback only.

Keeping both paths behind the same review_hunk() signature means the rest
of the pipeline (prompt_builder, response_parser, run_review, benchmark)
never needs to know which backend produced a result.
"""

import os
import time
import requests
from dataclasses import dataclass

OLLAMA_URL = "http://localhost:11434/api/generate"
# Override with: set DEVMESH_MODEL=<ollama tag>
# Default targets the closest Ollama-available tag for local CPU testing of
# the primary model. CONFIRM the exact tag via `ollama list` / `ollama pull
# qwen3:4b-instruct` before relying on this — Ollama's library naming for
# the 2507 non-thinking release may differ slightly from the AI Hub name.
# If unavailable, `ollama pull qwen3:4b` works but requires passing
# enable_thinking=False equivalent behavior isn't guaranteed identical to
# the dedicated -Instruct-2507 checkpoint used on AI Hub.
MODEL_NAME = os.environ.get("DEVMESH_MODEL", "qwen3:4b-instruct-2507-q4_K_M")

# "ollama" (default, always works) or "qnn" (production path, venue-hardware only)
BACKEND = os.environ.get("DEVMESH_BACKEND", "ollama").lower()

# Set via env var DEVMESH_MOCK_LLM=1 to bypass the backend entirely and return
# a canned response. Useful for testing the rest of the pipeline (diff
# extraction, parsing, fan-out) while Ollama/QNN issues are debugged separately.
# Works identically regardless of DEVMESH_BACKEND, so mock mode is always
# available as a safety net per Section 19.7.
MOCK_MODE = os.environ.get("DEVMESH_MOCK_LLM", "0") == "1"

MOCK_RESPONSE = """[CRITICAL] file.py:1 — Mocked finding: potential SQL injection. Fix: use parameterized queries.
[WARNING] file.py:2 — Mocked finding: unused variable. Fix: remove it.
[SUGGESTION] file.py:3 — Mocked finding: consider extracting this to a helper function."""

# --- QNN/Genie runtime config (Section 19.3/19.4/19.7) ----------------------
# The compiled QAIRT context binary — either downloaded directly from AI Hub
# for the confirmed winning config (Snapdragon X Elite CRD, NPU, w4a16,
# 4096 tokens, Qwen3-4B-Instruct-2507), or produced by your own cloud compile
# job — is what gets carried to the venue and pointed at here. Path is
# intentionally an env var, not hardcoded, since it will differ between
# whoever's laptop runs this and the venue machine.
QNN_CONTEXT_BINARY_PATH = os.environ.get("DEVMESH_QNN_BINARY", "")
QNN_MODEL_NAME = os.environ.get("DEVMESH_QNN_MODEL", "qwen3-4b-instruct-2507")


@dataclass
class LLMResult:
    raw_output: str
    latency_seconds: float


# Default timeout is generous because CPU-only inference on larger diffs
# (or the first call after Ollama starts, which includes model load time)
# can take well over a minute. Override with: set DEVMESH_TIMEOUT=600
DEFAULT_TIMEOUT = int(os.environ.get("DEVMESH_TIMEOUT", "420"))


def review_hunk(prompt: str, model: str = MODEL_NAME, timeout: int = DEFAULT_TIMEOUT) -> LLMResult:
    """
    Sends a single prompt to the selected backend and returns the raw text
    output plus latency (for the benchmark harness — Section 9/20).

    Signature is stable across backends per Section 19.3 — nothing else in
    the pipeline (prompt_builder, response_parser, run_review, benchmark)
    needs to change when DEVMESH_BACKEND switches from "ollama" to "qnn".

    If MOCK_MODE is on (DEVMESH_MOCK_LLM=1), skips the backend entirely and
    returns a canned response instantly, regardless of which backend is
    selected — the safety-net fallback stays intact per Section 19.7.
    """
    if MOCK_MODE:
        time.sleep(0.1)  # simulate a bit of latency for realistic timing logs
        return LLMResult(raw_output=MOCK_RESPONSE, latency_seconds=0.1)

    if BACKEND == "qnn":
        return _review_hunk_qnn(prompt, timeout)
    return _review_hunk_ollama(prompt, model, timeout)


def _review_hunk_ollama(prompt: str, model: str, timeout: int) -> LLMResult:
    """
    Original skeleton path (Section 15), unchanged. CPU-only dev/testing
    and live-demo fallback — always available regardless of QNN status.
    """
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
    }

    start = time.time()
    try:
        response = requests.post(OLLAMA_URL, json=payload, timeout=timeout)
        response.raise_for_status()
    except requests.exceptions.ConnectionError as e:
        raise RuntimeError(
            "Could not reach Ollama at http://localhost:11434. "
            "Is Ollama running? Try `ollama serve` in another terminal."
        ) from e
    except requests.exceptions.HTTPError as e:
        # Surface Ollama's actual error body instead of just the status code.
        # Common cause: model name doesn't match what's pulled (check `ollama list`).
        try:
            error_detail = response.json().get("error", response.text)
        except ValueError:
            error_detail = response.text
        raise RuntimeError(
            f"Ollama returned {response.status_code} for model '{model}': {error_detail}\n"
            f"Run `ollama list` to confirm the exact model name you have pulled."
        ) from e
    elapsed = time.time() - start

    data = response.json()
    return LLMResult(raw_output=data.get("response", ""), latency_seconds=elapsed)


def _review_hunk_qnn(prompt: str, timeout: int) -> LLMResult:
    """
    STUB — Section 19.3/19.4/19.7/20 design placeholder for the production
    on-device NPU path. This function's *shape* (inputs/outputs, error
    handling responsibilities) is real; its *body* cannot be finished until
    there's physical access to the Snapdragon X Elite NPU at the venue
    (July 11), per Section 19.7's "cannot be finished until venue hardware"
    list. Wiring this up is Hardik's Section 20 to-do item.

    Expected real implementation, once at the venue (in rough order):
      1. Load the compiled QAIRT context binary from QNN_CONTEXT_BINARY_PATH.
         Two ways to obtain it: (a) download directly from the Qwen3-4B-
         Instruct-2507 AI Hub page for the confirmed config — Snapdragon X
         Elite CRD, NPU, w4a16, GenieX/QAIRT, 4096 tokens — if a direct
         download is available for that exact config, which may skip the
         cloud-compile step entirely; or (b) the artifact produced by the
         WSL2 cloud-compile step (Section 19.7) if a custom compile was run.
      2. Tokenize `prompt` with the model's actual tokenizer (NOT
         diff_extractor.estimate_token_count, which is a rough char-based
         estimate for chunking decisions only — the real runtime needs the
         real tokenizer here).
      3. Run inference on the NPU via the GenieX/QAIRT runtime, respecting
         `timeout`.
      4. Decode the output tokens back to text.
      5. Return LLMResult(raw_output=<decoded text>, latency_seconds=<measured>)
         with the SAME shape response_parser.parse_findings() already expects
         — no changes needed downstream if this contract is honored.

    Until that's wired up, this deliberately raises rather than silently
    falling back to Ollama or returning fake data — a stub that pretends to
    work would corrupt real benchmark numbers (Section 9/20) by mixing NPU
    and CPU timings under the same "qnn" label. Use DEVMESH_MOCK_LLM=1 for
    testing the rest of the pipeline instead, or DEVMESH_BACKEND=ollama for
    a real (CPU) result.
    """
    if not QNN_CONTEXT_BINARY_PATH:
        raise NotImplementedError(
            "DEVMESH_BACKEND=qnn was selected but the QNN runtime is not "
            "wired up yet (Section 19.7: real NPU inference requires physical "
            "venue hardware, July 11). Set DEVMESH_QNN_BINARY once the "
            "compiled Qwen3-4B-Instruct-2507 context binary exists (check "
            "the AI Hub page first for a direct download of the confirmed "
            "config before running a full compile job), and finish "
            "_review_hunk_qnn() against the GenieX/QAIRT runtime API. "
            "In the meantime use DEVMESH_BACKEND=ollama (default) or "
            "DEVMESH_MOCK_LLM=1."
        )
    raise NotImplementedError(
        f"QNN_CONTEXT_BINARY_PATH is set ({QNN_CONTEXT_BINARY_PATH}) but the "
        f"actual runtime call is not implemented yet — see the docstring "
        f"above for the expected implementation steps. This is expected to "
        f"be finished on-site at the venue with the real Snapdragon X Elite "
        f"NPU available (model: {QNN_MODEL_NAME})."
    )


if __name__ == "__main__":
    # Manual smoke test — requires `ollama serve` running and `ollama pull phi3` done
    test_prompt = (
        "You are a senior code reviewer. Analyze the following git diff and "
        "identify issues.\n\nFor each issue respond ONLY in this exact format:\n"
        "[SEVERITY] FILE:LINE — Issue description. Fix: recommended fix.\n\n"
        "SEVERITY must be one of: CRITICAL, WARNING, SUGGESTION\n"
        "Do not explain. Do not add preamble.\n\n"
        'Git diff:\n+    query = "SELECT * FROM users WHERE id = " + user_id\n'
    )
    result = review_hunk(test_prompt)
    print(f"Latency: {result.latency_seconds:.2f}s")
    print("Output:")
    print(result.raw_output)
