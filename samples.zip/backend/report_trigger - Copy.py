"""
report_trigger.py

Orchestrates what happens when mobile sends {"type": "generate_report"}:
  1. Refuse if any finding is still undecided (mobile's UI is supposed to
     gate the button until everything's marked, but the backend shouldn't
     trust that blindly).
  2. For every false_positive decision, call the LLM again with the
     original diff + finding + the developer's comment (reiteration.py),
     and attach the verdict/text to that decision.
  3. Hand the full decision list to report_generator.generate_report() and
     return the resulting file path.

Called from ws_broadcaster.py's message handler, so this runs on the
asyncio event loop thread. The actual LLM calls (llm_client.review_hunk)
are synchronous/blocking (requests.post under the hood) — each one is run
via run_in_executor so a slow reiteration call doesn't freeze the WebSocket
server for other connected clients while it's in flight.
"""

import asyncio
from typing import Dict

import review_session
from llm_client import review_hunk
from reiteration import build_reiteration_prompt, parse_reiteration
from backend.report_generator_v1 import generate_report


async def handle_generate_report_request() -> Dict:
    if not review_session.session.has_findings():
        return {"type": "report_error", "message": "No findings to report — has a review run yet?"}

    pending = review_session.session.pending_ids()
    if pending:
        return {
            "type": "report_error",
            "message": f"{len(pending)} finding(s) still undecided: {', '.join(pending)}",
        }

    decisions = review_session.session.all_decisions()
    print(f"report trigger decissions{decisions}")
    loop = asyncio.get_event_loop()

    for d in decisions:
        if d.decision != "false_positive" or d.llm_reiteration:
            continue  # approved findings need no reiteration; already-reiterated ones are skipped

        prompt = build_reiteration_prompt(d.reviewed_finding, d.dev_comment)
        print(f"[report_trigger] Reiterating finding {d.reviewed_finding.finding.id} "
              f"({d.reviewed_finding.finding.file}:{d.reviewed_finding.finding.line})...")

        # review_hunk() is a blocking call (requests.post under the hood) —
        # offload it so the event loop can keep serving other WS traffic.
        result = await loop.run_in_executor(None, review_hunk, prompt)
        reiteration = parse_reiteration(result.raw_output)

        d.llm_verdict = reiteration.verdict
        d.llm_reiteration = reiteration.text
        print(f"    -> {reiteration.verdict}: {reiteration.text}")

    try:
        commit_info = review_session.session.get_commit_info()
        output_path = (
            f"devmesh_report_{commit_info.short_id}.txt" if commit_info else "devmesh_report.txt"
        )
        report_path = generate_report(decisions, commit_info=commit_info, output_path=output_path)
    except Exception as e:  # noqa: BLE001 — surface any report-generation failure back to mobile
        return {"type": "report_error", "message": f"Report generation failed: {e}"}

    return {"type": "report_ready", "path": report_path}
