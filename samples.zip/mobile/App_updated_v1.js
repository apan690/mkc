/**
 * DevMesh Mobile — Triage App
 *
 * Wire protocol matches backend/CHANGELOG.md (July 9, 2026 session):
 *
 *   Backend -> mobile (every broadcast):
 *   {
 *     "commit": { "id", "short_id", "author", "author_email", "message", "timestamp" },
 *     "file": "auth.py",
 *     "findings": [{ "id", "severity", "line", "description", "fix" }]
 *   }
 *
 *   Mobile -> backend:
 *   { "type": "finding_decision", "finding_id": "f3", "decision": "approved" }
 *   { "type": "finding_decision", "finding_id": "f7", "decision": "false_positive", "comment": "..." }
 *   { "type": "generate_report" }
 *
 *   Backend -> mobile (replies):
 *   { "type": "report_ready", "path": "..." }
 *   { "type": "report_error", "message": "..." }
 *   { "type": "decision_error", "message": "..." }
 *
 * KEY FIXES IN THIS PASS:
 * 1. Findings are keyed by the server-assigned `finding.id`, not an
 *    array-index-derived id. Index-based ids collide once the list is
 *    appended to across multiple messages/commits, which is what was
 *    causing duplicate-key re-renders and "replicated" rows on decision.
 * 2. `commit.short_id` is tracked. A new short_id means a new review run:
 *    findings/decisions/reasons/report state are all reset, instead of
 *    silently appending onto the previous commit's findings forever.
 * 3. Decisions are sent as `finding_decision` with a `decision` field
 *    (not the old `decision`/`status` mismatch) and `comment` (not `reason`)
 *    for false positives, matching the backend listener exactly.
 * 4. `report_ready` / `report_error` / `decision_error` replies are now
 *    handled instead of being silently dropped by flattenPayload. In
 *    particular report_error un-sticks the Generate Report button so the
 *    user can fix the undecided findings and retry.
 */

import React, { useEffect, useRef, useState, useCallback } from "react";
import {
  SafeAreaView,
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Platform,
  Modal,
  TextInput,
  KeyboardAvoidingView,
} from "react-native";

// ---- CONFIG ---------------------------------------------------------------
const SERVER_IP = "192.168.0.105";
const SERVER_PORT = 8765;
const WS_URL = `ws://${SERVER_IP}:${SERVER_PORT}`;
const CONNECTION_TIMEOUT_MS = 3000;

const FALLBACK_FINDINGS = [
  {
    id: "demo-1",
    severity: "CRITICAL",
    file: "auth.py",
    line: 42,
    description: "SQL injection vulnerability",
    fix: "Use parameterized queries instead of string formatting",
  },
  {
    id: "demo-2",
    severity: "WARNING",
    file: "utils.py",
    line: 17,
    description: "Unused import 'os'",
    fix: "Remove the unused import",
  },
  {
    id: "demo-3",
    severity: "SUGGESTION",
    file: "helpers.py",
    line: 55,
    description: "Consider extracting to separate function",
    fix: "Pull the repeated block into a named helper",
  },
];

// Unpacks the backend's { commit, file, findings: [...] } wire shape into a
// flat array the UI renders one card per finding for. Each finding keeps
// the server-assigned `id` — this is the identity used everywhere below,
// never a locally-derived index.
function flattenPayload(payload) {
  if (!payload || !Array.isArray(payload.findings)) return [];
  return payload.findings.map((f) => ({
    id: f.id,
    severity: f.severity,
    file: payload.file,
    line: f.line,
    description: f.description,
    fix: f.fix,
  }));
}

const SEVERITY_STYLES = {
  CRITICAL: { color: "#EF4444", bg: "#FEF2F2", icon: "\u{1F534}", label: "CRITICAL" },
  WARNING: { color: "#D97706", bg: "#FFFBEB", icon: "\u{1F7E1}", label: "WARNING" },
  SUGGESTION: { color: "#16A34A", bg: "#F0FDF4", icon: "\u{1F7E2}", label: "SUGGESTION" },
};

export default function App() {
  const [findings, setFindings] = useState([]);
  const [commit, setCommit] = useState(null); // { id, short_id, author, message, timestamp } | null
  const [status, setStatus] = useState("connecting");
  const [expandedIds, setExpandedIds] = useState({});
  const [decisions, setDecisions] = useState({}); // id -> "approved" | "false_positive"
  const [reasons, setReasons] = useState({}); // id -> reason text
  const [attemptCount, setAttemptCount] = useState(0);
  const [demoActive, setDemoActive] = useState(false);

  // False-positive reason modal state
  const [fpModalTarget, setFpModalTarget] = useState(null); // { id, finding } | null
  const [fpReasonDraft, setFpReasonDraft] = useState("");

  // Report generation state
  const [reportRequested, setReportRequested] = useState(false);
  const [reportStatus, setReportStatus] = useState(null); // { type: "ready"|"error", message } | null

  const wsRef = useRef(null);
  const reconnectTimerRef = useRef(null);
  // Mirrors `commit` in a ref so the onmessage closure (set up once in the
  // effect) always sees the latest known commit without re-subscribing.
  const commitRef = useRef(null);

  const showDemoData = useCallback(() => {
    setDemoActive(true);
    setCommit(null);
    setDecisions({});
    setReasons({});
    setReportRequested(false);
    setReportStatus(null);
    setFindings(FALLBACK_FINDINGS);
  }, []);

  const hideDemoData = useCallback(() => {
    setDemoActive(false);
    setFindings([]);
  }, []);

  // Resets all per-review-run state. Called whenever a broadcast arrives
  // for a commit.short_id we haven't seen yet, so a new review run never
  // inherits stale findings/decisions from the previous one.
  const resetForNewCommit = useCallback((newCommit, initialFindings) => {
    commitRef.current = newCommit || null;
    setCommit(newCommit || null);
    setFindings(initialFindings);
    setDecisions({});
    setReasons({});
    setReportRequested(false);
    setReportStatus(null);
    setDemoActive(false);
  }, []);

  // ---- WebSocket send helpers ----------------------------------------------
  const sendMessage = useCallback((message) => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    } else {
      console.log("[DevMesh] Socket not open — message not sent:", message);
    }
  }, []);

  const sendDecision = useCallback(
    (id, decisionValue, comment) => {
      sendMessage({
        type: "finding_decision",
        finding_id: id,
        decision: decisionValue,
        ...(decisionValue === "false_positive" ? { comment } : {}),
      });
    },
    [sendMessage]
  );

  useEffect(() => {
    let mounted = true;
    let reconnectAttempts = 0;
    const MAX_RETRIES = 20;

    const connect = () => {
      if (!mounted) return;

      reconnectAttempts += 1;
      if (mounted) setAttemptCount(reconnectAttempts);

      const ws = new WebSocket(WS_URL);
      wsRef.current = ws;

      const timeout = setTimeout(() => {
        if (ws.readyState !== WebSocket.OPEN && mounted) {
          setStatus("waiting");
          ws.close();
        }
      }, CONNECTION_TIMEOUT_MS);

      ws.onopen = () => {
        clearTimeout(timeout);
        reconnectAttempts = 0;
        if (mounted) {
          setStatus("live");
          setAttemptCount(0);
          setDemoActive(false);
        }
      };

      ws.onmessage = (event) => {
        let payload;
        try {
          payload = JSON.parse(event.data);
        } catch (e) {
          console.warn("[DevMesh] Parse error:", e);
          return;
        }
        if (!mounted) return;

        // Control replies (not a findings broadcast).
        if (payload.type === "report_ready") {
          setReportStatus({ type: "ready", message: payload.path });
          return;
        }
        if (payload.type === "report_error") {
          setReportRequested(false);
          setReportStatus({ type: "error", message: payload.message });
          return;
        }
        if (payload.type === "decision_error") {
          setReportStatus({ type: "error", message: payload.message });
          return;
        }

        // Findings broadcast.
        const newFindings = flattenPayload(payload);
        if (newFindings.length === 0) return;

        const incomingShortId = payload.commit?.short_id ?? null;
        const currentShortId = commitRef.current?.short_id ?? null;

        if (incomingShortId !== currentShortId) {
          // New review run — replace, don't append.
          resetForNewCommit(payload.commit, newFindings);
        } else {
          setFindings((prev) => [...prev, ...newFindings]);
        }
      };

      ws.onerror = (e) => {
        console.log("[DevMesh] ERROR:", e.message || e);
      };

      ws.onclose = () => {
        clearTimeout(timeout);
        if (!mounted) return;
        if (mounted) setStatus("waiting");
        if (reconnectAttempts < MAX_RETRIES) {
          const delay = Math.min(reconnectAttempts * 1000, 5000);
          reconnectTimerRef.current = setTimeout(() => connect(), delay);
        }
      };
    };

    connect();

    return () => {
      mounted = false;
      clearTimeout(reconnectTimerRef.current);
      if (wsRef.current) {
        wsRef.current.onclose = null;
        wsRef.current.close();
      }
    };
  }, [resetForNewCommit]);

  const toggleExpand = (id) => {
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Approve is a direct decision — no reason required.
  const approve = (id) => {
    setDecisions((prev) => ({ ...prev, [id]: "approved" }));
    sendDecision(id, "approved");
  };

  // False Positive opens the reason modal instead of deciding immediately.
  const openFalsePositiveModal = (id, finding) => {
    setFpReasonDraft(reasons[id] || "");
    setFpModalTarget({ id, finding });
  };

  const cancelFalsePositiveModal = () => {
    setFpModalTarget(null);
    setFpReasonDraft("");
  };

  const confirmFalsePositive = () => {
    if (!fpModalTarget) return;
    const trimmed = fpReasonDraft.trim();
    if (trimmed.length === 0) return; // reason is required — button also disabled below

    const { id } = fpModalTarget;
    setDecisions((prev) => ({ ...prev, [id]: "false_positive" }));
    setReasons((prev) => ({ ...prev, [id]: trimmed }));
    sendDecision(id, "false_positive", trimmed);

    setFpModalTarget(null);
    setFpReasonDraft("");
  };

  // ---- Generate Report gating ----------------------------------------------
  const allResolved =
    findings.length > 0 &&
    findings.every((f) => decisions[f.id] === "approved" || decisions[f.id] === "false_positive");

  const handleGenerateReport = () => {
    if (!allResolved || reportRequested) return;
    setReportRequested(true);
    setReportStatus(null);
    sendMessage({ type: "generate_report" });
  };

  const renderItem = ({ item }) => {
    const id = item.id;
    const sev = SEVERITY_STYLES[item.severity] || SEVERITY_STYLES.SUGGESTION;
    const expanded = !!expandedIds[id];
    const decision = decisions[id];
    const reason = reasons[id];

    return (
      <View style={[styles.card, { backgroundColor: sev.bg, borderLeftColor: sev.color }]}>
        <View style={styles.cardHeader}>
          <Text style={[styles.severityBadge, { color: sev.color }]}>
            {sev.icon} {sev.label}
          </Text>
          <Text style={styles.location}>
            {item.file}:{item.line}
          </Text>
        </View>

        <Text style={styles.issue}>{item.description}</Text>

        {expanded && (
          <View style={styles.fixBox}>
            <Text style={styles.fixLabel}>Recommended fix</Text>
            <Text style={styles.fixText}>{item.fix}</Text>
          </View>
        )}

        {decision === "false_positive" && reason && (
          <View style={styles.reasonBox}>
            <Text style={styles.reasonLabel}>Your reason</Text>
            <Text style={styles.reasonText}>{reason}</Text>
          </View>
        )}

        <View style={styles.actionRow}>
          <TouchableOpacity onPress={() => toggleExpand(id)} style={styles.actionButtonGhost}>
            <Text style={styles.actionGhostText}>{expanded ? "Hide fix" : "Explain"}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => openFalsePositiveModal(id, item)}
            style={[
              styles.actionButtonGhost,
              decision === "false_positive" && styles.actionFalsePositiveActive,
            ]}
          >
            <Text style={styles.actionGhostText}>
              {decision === "false_positive" ? "False Positive" : "Mark False Positive"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => approve(id)}
            style={[styles.actionButtonSolid, decision === "approved" && styles.actionApprovedActive]}
          >
            <Text style={styles.actionSolidText}>
              {decision === "approved" ? "\u2713 Approved" : "Approve"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const statusLabel = {
    connecting: "Connecting to review server...",
    live: "Live \u2014 streaming from AI PC",
    waiting: `Waiting for AI PC${attemptCount > 1 ? ` (attempt ${attemptCount})` : ""}`,
  }[status];

  const statusColor = status === "live" ? "#16A34A" : status === "waiting" ? "#64748B" : "#94A3B8";
  const showDemoBanner = demoActive && status !== "live";

  const resolvedCount = findings.filter(
    (f) => decisions[f.id] === "approved" || decisions[f.id] === "false_positive"
  ).length;

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#0F172A" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>DevMesh</Text>
        <Text style={styles.headerSubtitle}>On-device code review, in your pocket</Text>
        <View style={styles.statusRow}>
          <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
          <Text style={styles.statusText}>{statusLabel}</Text>
        </View>
        {commit && (
          <Text style={styles.commitText} numberOfLines={1}>
            {commit.short_id} {"\u2014"} {commit.message}
          </Text>
        )}
        {showDemoBanner && (
          <View style={styles.demoBanner}>
            <Text style={styles.demoBannerText}>SAMPLE DATA — not from a live review</Text>
            <TouchableOpacity onPress={hideDemoData}>
              <Text style={styles.demoBannerAction}>Hide</Text>
            </TouchableOpacity>
          </View>
        )}
        {reportStatus && (
          <View
            style={[
              styles.reportStatusBanner,
              reportStatus.type === "error" ? styles.reportStatusError : styles.reportStatusReady,
            ]}
          >
            <Text style={styles.reportStatusText}>
              {reportStatus.type === "ready"
                ? `Report ready: ${reportStatus.message}`
                : reportStatus.message}
            </Text>
          </View>
        )}
      </View>

      <FlatList
        data={findings}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>
              {status === "live" ? "Waiting for findings..." : "Not connected to the AI PC yet."}
            </Text>
            {status !== "live" && (
              <TouchableOpacity onPress={showDemoData} style={styles.demoButton}>
                <Text style={styles.demoButtonText}>Show Demo Data</Text>
              </TouchableOpacity>
            )}
          </View>
        }
      />

      {findings.length > 0 && (
        <View style={styles.reportBar}>
          <Text style={styles.reportProgress}>
            {resolvedCount} / {findings.length} resolved
          </Text>
          <TouchableOpacity
            onPress={handleGenerateReport}
            disabled={!allResolved || reportRequested}
            style={[
              styles.generateButton,
              (!allResolved || reportRequested) && styles.generateButtonDisabled,
            ]}
          >
            <Text style={styles.generateButtonText}>
              {reportRequested ? "Report Requested…" : "Generate Report"}
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {/* False Positive reason modal */}
      <Modal
        visible={!!fpModalTarget}
        transparent
        animationType="fade"
        onRequestClose={cancelFalsePositiveModal}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : undefined}
          style={styles.modalBackdrop}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Why is this a false positive?</Text>
            {fpModalTarget && (
              <Text style={styles.modalSubtitle}>
                {fpModalTarget.finding.file}:{fpModalTarget.finding.line}
              </Text>
            )}
            <TextInput
              style={styles.modalInput}
              placeholder="e.g. This is behind an internal-only VPN, low risk."
              placeholderTextColor="#94A3B8"
              value={fpReasonDraft}
              onChangeText={setFpReasonDraft}
              multiline
              autoFocus
            />
            <View style={styles.modalActions}>
              <TouchableOpacity onPress={cancelFalsePositiveModal} style={styles.modalCancelButton}>
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={confirmFalsePositive}
                disabled={fpReasonDraft.trim().length === 0}
                style={[
                  styles.modalConfirmButton,
                  fpReasonDraft.trim().length === 0 && styles.modalConfirmDisabled,
                ]}
              >
                <Text style={styles.modalConfirmText}>Submit</Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#0F172A",
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === "android" ? 20 : 8,
    paddingBottom: 16,
    backgroundColor: "#0F172A",
  },
  headerTitle: {
    color: "#FFFFFF",
    fontSize: 26,
    fontWeight: "700",
  },
  headerSubtitle: {
    color: "#94A3B8",
    fontSize: 13,
    marginTop: 2,
  },
  statusRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  statusText: {
    color: "#CBD5E1",
    fontSize: 12,
  },
  commitText: {
    color: "#64748B",
    fontSize: 11,
    marginTop: 6,
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  listContent: {
    padding: 16,
    paddingBottom: 40,
    backgroundColor: "#F1F5F9",
    flexGrow: 1,
  },
  emptyState: {
    marginTop: 60,
    alignItems: "center",
  },
  emptyText: {
    color: "#94A3B8",
    fontSize: 14,
    marginBottom: 16,
  },
  demoButton: {
    borderWidth: 1,
    borderColor: "#CBD5E1",
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  demoButtonText: {
    color: "#475569",
    fontSize: 13,
    fontWeight: "600",
  },
  demoBanner: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#78350F",
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
    marginTop: 10,
  },
  demoBannerText: {
    color: "#FDE68A",
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.3,
  },
  demoBannerAction: {
    color: "#FDE68A",
    fontSize: 11,
    fontWeight: "700",
    textDecorationLine: "underline",
  },
  reportStatusBanner: {
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
    marginTop: 10,
  },
  reportStatusReady: {
    backgroundColor: "#064E3B",
  },
  reportStatusError: {
    backgroundColor: "#7F1D1D",
  },
  reportStatusText: {
    color: "#F1F5F9",
    fontSize: 11,
    fontWeight: "600",
  },
  card: {
    borderRadius: 12,
    borderLeftWidth: 4,
    padding: 14,
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  severityBadge: {
    fontWeight: "700",
    fontSize: 12,
    letterSpacing: 0.5,
  },
  location: {
    fontSize: 12,
    color: "#475569",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
  },
  issue: {
    fontSize: 15,
    color: "#0F172A",
    fontWeight: "500",
    marginBottom: 8,
  },
  fixBox: {
    backgroundColor: "rgba(255,255,255,0.6)",
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  fixLabel: {
    fontSize: 11,
    fontWeight: "700",
    color: "#334155",
    marginBottom: 3,
    textTransform: "uppercase",
  },
  fixText: {
    fontSize: 13,
    color: "#1E293B",
  },
  reasonBox: {
    backgroundColor: "rgba(100,116,139,0.12)",
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },
  reasonLabel: {
    fontSize: 11,
    fontWeight: "700",
    color: "#475569",
    marginBottom: 3,
    textTransform: "uppercase",
  },
  reasonText: {
    fontSize: 13,
    color: "#334155",
  },
  actionRow: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 8,
  },
  actionButtonGhost: {
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  actionGhostText: {
    fontSize: 12,
    color: "#475569",
    fontWeight: "600",
  },
  actionFalsePositiveActive: {
    backgroundColor: "rgba(100,116,139,0.15)",
  },
  actionButtonSolid: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
    backgroundColor: "#0F172A",
  },
  actionSolidText: {
    fontSize: 12,
    color: "#FFFFFF",
    fontWeight: "700",
  },
  actionApprovedActive: {
    backgroundColor: "#16A34A",
  },
  reportBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingVertical: 14,
    backgroundColor: "#0F172A",
    borderTopWidth: 1,
    borderTopColor: "#1E293B",
  },
  reportProgress: {
    color: "#94A3B8",
    fontSize: 12,
  },
  generateButton: {
    backgroundColor: "#5B8DEF",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 8,
  },
  generateButtonDisabled: {
    backgroundColor: "#334155",
  },
  generateButtonText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "700",
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(15,23,42,0.6)",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    padding: 20,
  },
  modalTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#0F172A",
    marginBottom: 4,
  },
  modalSubtitle: {
    fontSize: 12,
    color: "#64748B",
    fontFamily: Platform.OS === "ios" ? "Menlo" : "monospace",
    marginBottom: 14,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: "#CBD5E1",
    borderRadius: 8,
    padding: 12,
    minHeight: 90,
    fontSize: 14,
    color: "#0F172A",
    textAlignVertical: "top",
    marginBottom: 16,
  },
  modalActions: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 10,
  },
  modalCancelButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  modalCancelText: {
    color: "#64748B",
    fontSize: 13,
    fontWeight: "600",
  },
  modalConfirmButton: {
    backgroundColor: "#0F172A",
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
  },
  modalConfirmDisabled: {
    backgroundColor: "#94A3B8",
  },
  modalConfirmText: {
    color: "#FFFFFF",
    fontSize: 13,
    fontWeight: "700",
  },
});