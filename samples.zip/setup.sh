#!/bin/bash
#
# setup.sh
#
# One-command setup for DevMesh on a clean clone.
#
# WHAT THIS DOES:
#   1. Installs Python dependencies (backend/requirements.txt)
#   2. Installs the post-commit git hook (hooks/post-commit -> .git/hooks/post-commit)
#   3. Starts the FastAPI webhook listener in the background (port 8000)
#   4. Starts the Expo mobile dev server in the background (fixed port 5678)
#
# All background process logs land in ./logs/ next to this script
# (devmesh_webhook.log, devmesh_expo.log) — check there first if
# something doesn't seem to have started.
#
# TWO BUGS FOUND DURING REAL-DEVICE TESTING, BOTH FIXED HERE:
#   - hooks/post-commit used to spawn its own `python run_review.py`,
#     which raced with this script's webhook_server for port 8765
#     (the WebSocket port) and lost silently — findings never reached
#     the phone even though the report file updated fine. Fixed by
#     having the hook curl the already-running webhook listener instead
#     of starting a second process. See hooks/post-commit for the full
#     writeup.
#   - Expo's default port (8081) being taken caused a silent hang here,
#     since a backgrounded/non-interactive process can't answer Expo's
#     "use another port?" prompt. Fixed by pinning --port 5678.
#
# NOTE ON STEP 4: Expo's dev server is normally run in its own foreground
# terminal — it prints a live QR code and accepts keypresses (r = reload,
# a/i = open on Android/iOS, etc). Backgrounding it here trades that
# interactivity for one-command convenience: the QR code still gets
# written to a log file (see below) and re-scanning it works fine, but
# you lose the keypress shortcuts. If you want the interactive experience,
# skip step 4's automation and just run `cd mobile && npx expo start`
# yourself in its own terminal — that's equally valid and arguably nicer
# for active mobile development.
# WHAT THIS DELIBERATELY DOES NOT DO:
#   Start the WebSocket broadcaster as a separate step. It doesn't need
#   to be — ws_broadcaster.py starts its server (ws://0.0.0.0:8765)
#   automatically the moment it's imported, which happens as soon as
#   either run_review.py (via a commit) or webhook_server.py (via this
#   script) runs. Starting it a third time here would just be a wasted,
#   redundant no-op at best (Vatsal's _start_server_thread() is
#   idempotent) — but running two full run_review.py processes
#   simultaneously is NOT safe, so this script is careful not to do that.
#
# USAGE:
#   ./setup.sh
#
# Run from the repo root (the folder containing backend/, hooks/, samples/, etc).
#
# NOTE: deliberately NOT using `set -e` here. A pip hiccup (e.g. a
# system-managed Python refusing global installs, a flaky network) is not
# a reason to also skip installing the git hook — that's the step most
# worth getting right even if deps need a manual follow-up. Each step
# below checks its own result and reports clearly instead.

set +e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

mkdir -p "$SCRIPT_DIR/logs"

echo "=== DevMesh Setup ==="
echo

# --- 0. Sanity checks -------------------------------------------------
if [ ! -d "backend" ]; then
    echo "ERROR: backend/ not found. Run this script from the repo root."
    exit 1
fi

if [ ! -d ".git" ]; then
    echo
    echo "  ############################################################"
    echo "  #  WARNING: no .git found in $(pwd)"
    echo "  #  The post-commit hook CANNOT be installed, which means"
    echo "  #  NO commit will EVER trigger a review — silently, with no"
    echo "  #  further warning once setup finishes."
    echo "  #"
    echo "  #  Fix: run 'git init' (or clone the real repo) here, then"
    echo "  #  re-run this script."
    echo "  ############################################################"
    echo
    IS_GIT_REPO=0
else
    IS_GIT_REPO=1
fi

# --- 1. Install Python dependencies ------------------------------------
echo "[1/4] Installing Python dependencies from backend/requirements.txt..."
if command -v pip3 &> /dev/null; then
    PIP_CMD=pip3
else
    PIP_CMD=pip
fi
if $PIP_CMD install -r backend/requirements.txt; then
    echo "      Done."
else
    echo "      WARNING: pip install failed (see above). Continuing with hook"
    echo "      install anyway — you may need to install deps manually, e.g.:"
    echo "        $PIP_CMD install -r backend/requirements.txt --break-system-packages"
    echo "      or from a virtualenv."
fi
echo

# --- 2. Install the post-commit hook -----------------------------------
if [ "$IS_GIT_REPO" -eq 1 ]; then
    echo "[2/4] Installing post-commit git hook..."
    if [ ! -f "hooks/post-commit" ]; then
        echo "      WARNING: hooks/post-commit not found — skipping hook install."
    else
        cp hooks/post-commit .git/hooks/post-commit
        chmod +x .git/hooks/post-commit
        echo "      Installed to .git/hooks/post-commit (and made executable)."
    fi
else
    echo "[2/4] SKIPPED — not a git repo (see WARNING above). No commit will"
    echo "      trigger a review until you run 'git init' and re-run setup.sh."
fi
echo

# --- 3. Start the webhook listener --------------------------------------
echo "[3/4] Starting FastAPI webhook listener on port 8000..."
cd backend

# Guard against double-starting the listener if setup.sh is re-run while
# a previous instance is still alive. Using curl against /health rather
# than lsof, since lsof isn't reliably available on every teammate's
# machine (notably Windows/Git Bash), while curl already is (used below
# in the "next steps" output too).
if curl -s -o /dev/null -m 2 http://localhost:8000/health; then
    echo "      Something is already listening on port 8000 (health check"
    echo "      responded) — leaving it running, not starting a second instance."
else
    nohup uvicorn webhook_server:app --host 0.0.0.0 --port 8000 > "$SCRIPT_DIR/logs/devmesh_webhook.log" 2>&1 &
    sleep 1
    echo "      Started (PID $!). Logs: $SCRIPT_DIR/logs/devmesh_webhook.log"
fi

cd "$SCRIPT_DIR"
echo

# --- 4. Start the mobile app (Expo) --------------------------------------
echo "[4/4] Starting Expo mobile dev server..."
if [ ! -d "mobile" ]; then
    echo "      WARNING: mobile/ not found — skipping. Run 'npx expo start' manually"
    echo "      from wherever the mobile app lives."
else
    cd mobile

    if [ ! -d "node_modules" ]; then
        echo "      node_modules not found — running npm install first (one-time)..."
        if ! npm install; then
            echo "      WARNING: npm install failed. Fix that, then run"
            echo "      'npx expo start' manually from mobile/."
            cd "$SCRIPT_DIR"
            echo
            echo "=== Setup complete (mobile step skipped) ==="
            exit 0
        fi
    fi

    # Backgrounded for one-command convenience — see the note near the top
    # of this script for the tradeoff (you lose Expo's interactive
    # keypress shortcuts this way). The QR code still lands in the log
    # file below and can be re-scanned from there; if you'd rather have
    # the live interactive terminal, kill this process and run
    # `npx expo start` yourself in its own terminal instead.
    #
    # --port 5678 is pinned deliberately: BUG FOUND & FIXED — when the
    # default port 8081 was already taken, Expo normally prompts
    # interactively ("use port 8082 instead? Y/n"), but since this
    # process is backgrounded/non-interactive there was no terminal to
    # answer that prompt, so it just silently never started the dev
    # server. Pinning a fixed port sidesteps the prompt entirely. If
    # 5678 is ever taken on your machine too, change it here.
    nohup npx expo start --port 5678 > "$SCRIPT_DIR/logs/devmesh_expo.log" 2>&1 &
    EXPO_PID=$!
    sleep 3
    echo "      Started on port 5678 (PID $EXPO_PID)."
    echo "      QR code + dev server URL: $SCRIPT_DIR/logs/devmesh_expo.log"
    echo "      View it now with: cat \"$SCRIPT_DIR/logs/devmesh_expo.log\""

    cd "$SCRIPT_DIR"
fi
echo

# --- Done ----------------------------------------------------------------
echo "=== Setup complete ==="
echo
echo "Next steps:"
echo "  - Make a commit (e.g. against a file in samples/) to trigger a review"
echo "    automatically via the post-commit hook."
echo "  - Or simulate a GitHub PR event:"
echo "      curl -X POST http://localhost:8000/webhook \\"
echo "        -H \"X-GitHub-Event: pull_request\" \\"
echo "        -H \"Content-Type: application/json\" \\"
echo "        -d '{\"action\": \"opened\", \"pull_request\": {\"number\": 1}}'"
echo "  - Check webhook listener health: curl http://localhost:8000/health"
echo "  - Scan the QR code to open the mobile app: cat \"$SCRIPT_DIR/logs/devmesh_expo.log\""
echo "    (or open the dev server URL shown there in Expo Go directly)"
echo "  - Findings stream over ws://0.0.0.0:8765 to the mobile app (if running),"
echo "    and a plain-text report is written to backend/devmesh_report.txt."
echo
